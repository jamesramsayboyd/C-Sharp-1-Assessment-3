﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VehicleRegistrationForm
{

    /* James Boyd 30041547
     * C Sharp 1 Assessment 3
     * A program that tracks vehicle registrations in a large city car park
     * version 1.1 - All functionality implemented, near full error trapping, 
     * some error messaging, no tooltips
     */
    public partial class VehicleRegistration : Form
    {
        public VehicleRegistration()
        {
            InitializeComponent();
            DisplayList();
        }

        //List<string> RegoList = new List<string>() { "1HFM997", "6AW828" };
        List<string> RegoList = new List<string>() { };


        #region Open file/Save file        
        /* 
         * OPEN: The program reads default data into the List<> when it starts. 
         * When the OPEN button is clicked the user can select different 
         * data from a text file called “demo_nn.txt”
         */
        //TODO: Test, add error trapping, comments, error messaging, tooltips
        private void ButtonOpen_Click(object sender, EventArgs e)
        {
            string fileName = "Rainbow.bin";
            OpenFileDialog OpenBinary = new OpenFileDialog();
            DialogResult sr = OpenBinary.ShowDialog();
            if (sr == DialogResult.OK)
            {
                fileName = OpenBinary.FileName;
            }
            try
            {
                RegoList.Clear();
                using (Stream stream = File.Open(fileName, FileMode.Open))
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    while (stream.Position < stream.Length)
                    {
                        RegoList.Add((string)binaryFormatter.Deserialize(stream));
                    }
                }
                DisplayList();
            }
            catch (IOException)
            {
                MessageBox.Show("cannot open file");
            }
        }

        /*
         * CLOSE and SAVE: Create a SAVE button which will open a save dialog box 
         * and allow the user to save all the data back to a text file. When the 
         * program closes all data from the List<> will be written back to a 
         * single text file called “demo_nn.txt” file.
         */
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            string fileName = "Rainbow.bin";
            SaveFileDialog saveBinary = new SaveFileDialog();
            DialogResult sr = saveBinary.ShowDialog();
            if (sr == DialogResult.Cancel)
            {
                saveBinary.FileName = fileName;
            }
            if (sr == DialogResult.OK)
            {
                fileName = saveBinary.FileName;
            }
            try
            {
                using (Stream stream = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter binFormatter = new BinaryFormatter();
                    foreach (var item in RegoList)
                    {
                        binFormatter.Serialize(stream, item);
                    }
                }
            }
            catch (IOException)
            {
                MessageBox.Show("cannot save file");
            }
        }

        #endregion Open file/Save file

        #region Add/Delete/Edit
        /* ADD Button: To add a rego plate to the List<> the user 
         * will type the data value (rego plate info) into the
         * TextBox and click the ENTER button. The data will be 
         * added to the List<> and the TextBox will be cleared, 
         * and the cursor will focus in the TextBox. If the TextBox 
         * is empty the program should raise an error message.
         */
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            // Checks to make sure user has entered a number in Text Box
            if (!string.IsNullOrEmpty(TextBoxInput.Text))
            {
                RegoList.Add(TextBoxInput.Text);
                DisplayList();
                StripStatus.Text = "Registration plate added";
                TextBoxInput.Clear();
                TextBoxInput.Select();
            }
            else
            {
                StripStatus.Text = "ERROR: Enter a registration number in the Text Box";
            }
        }

        /* DELETE Button: There are two options 
         * to remove a rego plate item from the List<>. Method One: 
         * double click a data item from the ListBox and click the OK 
         * button in the popup dialog box. The data item will be removed 
         * from the List<>. Method Two: the user will enter the rego 
         * plate information into the TextBox and click the DELETE 
         * button. The data will be removed from the List<> and the 
         * TextBox will be cleared, and the cursor will focus in the TextBox.
         */
        // Method One fully implemented
        // TODO: Add Method Two, error messaging for both options
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            // Code for Yes/No confirmation message
            DialogResult delRecord = MessageBox.Show("Do you want to delete this registration number?",
                "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (delRecord == DialogResult.Yes)
            {
                RegoList.Remove(ListBoxOutput.SelectedItem.ToString());
                DisplayList();
                StripStatus.Text = "Registration number was deleted";
                TextBoxInput.Clear();
                TextBoxInput.Select();
            }
            else
            {
                // If user chooses not to delete
                StripStatus.Text = "Registration number was not deleted";
            }
        }

        /* EDIT Button: To edit a rego plate click (select) a data item 
         * from the ListBox so that is appears in the TextBox. Alter the 
         * information and click the EDIT button. The updated information 
         * is written back to the List<> and the TextBox is cleared, and 
         * the cursor refocus in the TextBox. (you are not permitted to 
         * use an add/delete option)
         */
        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            // Checks to see if user has selected an item in the Listbox
            if (ListBoxOutput.SelectedIndex != -1)
            {
                // Checks to see if user has entered text to edit
                if (ListBoxOutput.SelectedItem.ToString() != TextBoxInput.Text)
                {
                    // Code for Yes/No confirmation message
                    DialogResult delRecord = MessageBox.Show("Do you want to edit this record?",
                        "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    Int32.TryParse(TextBoxInput.Text, out int edited);
                    if (delRecord == DialogResult.Yes)
                    {
                        // User chooses to edit
                        RegoList[ListBoxOutput.SelectedIndex] = TextBoxInput.Text;
                        DisplayList();
                        StripStatus.Text = "Registration number was edited";
                        TextBoxInput.Clear();
                        TextBoxInput.Select();
                    }
                    else
                    {
                        // If user chooses not to edit
                        TextBoxInput.Clear();
                        TextBoxInput.Select();
                        StripStatus.Text = "Registration number was not edited";
                    }
                }
                else
                {
                    // If user hasn't changed rego number
                    StripStatus.Text = "Please enter edited text";
                }
            }
            else
            {
                // If user clicks button without selecting Listbox item
                StripStatus.Text = "ERROR: Cannot edit, no item selected";
            }
        }

        #endregion Add/Delete/Edit

        #region Search
        /*
         * BINARY SEARCH: To find a specific rego plate the user will type the information 
         * into the TextBox and click the BINARY SEARCH button. If the rego plate is found, 
         * then a confirmation message should be displayed. If the rego plate is not found, 
         * then a message should be displayed, and the TextBox cleared, and the cursor 
         * refocused. The search code must use the built-in Binary search.
         */
        private void ButtonBinary_Click(object sender, EventArgs e)
        {
            // Checks whether list is empty before searching
            if (RegoList.Count() > 0)
            {
                // Checks if user has entered a search query in the Text Box
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    int RegoIndex = RegoList.BinarySearch(TextBoxInput.Text);
                    if (RegoIndex >= 0)
                    {
                        // Search target found
                        //StripStatus.Text = "Found via Binary Search at index " + RegoIndex;
                        StripStatus.Text = "Found via Binary Search";
                        ListBoxOutput.SelectedIndex = RegoIndex;
                    }
                    else
                    {
                        // Search target not found
                        StripStatus.Text = "Not Found";
                    }
                    TextBoxInput.Clear();
                    TextBoxInput.Select();
                }
                else
                {
                    // If user hasn't entered text in the textbox
                    StripStatus.Text = "ERROR: Enter a search target in the textbox";
                }
            }
            else
            {
                // If list is empty
                StripStatus.Text = "ERROR: Cannot search, no data in list";
            }
        }

        /*
         * LINEAR SEARCH: second search button that implements a linear search algorithm. 
         * To find a rego plate the user will type the information into the TextBox 
         * and click the LINEAR SEARCH button. If the rego plate is found, then a 
         * confirmation message should be displayed. If the rego plate is not found, 
         * then a message should be displayed, and the TextBox cleared, and the cursor 
         * refocused.
         */
        private void ButtonLinear_Click(object sender, EventArgs e)
        {
            // Checks whether there is data in list
            if (RegoList.Count() > 0)
            {
                // Checks if user has entered a search target
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    string target = TextBoxInput.Text;
                    foreach (var rego in RegoList)
                    {
                        if (rego == target)
                        {
                            StripStatus.Text = "Found via Linear Search";
                            ListBoxOutput.SelectedItem = target;
                            break;
                        }
                        else
                        {
                            StripStatus.Text = "Not Found";
                        }
                        TextBoxInput.Clear();
                        TextBoxInput.Select();
                    }
                }
                else
                {
                    // If user hasn't entered a target in the textbox
                    StripStatus.Text = "ERROR: Enter a search target in the textbox";
                }

            }
            else
            {
                // If the list is empty
                StripStatus.Text = "ERROR: Cannot search, no data in list";
            }
        }
        #endregion Search

        #region Reset/Tag
        /*
         * RESET: Add a RESET button to clear all the data items from the List<>. 
         * The ListBox and TextBox should also be cleared.
         */
        private void ButtonReset_Click(object sender, EventArgs e)
        {
            // Code for Yes/No confirmation message
            DialogResult delRecord = MessageBox.Show("Do you want to delete all data?",
                "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (delRecord == DialogResult.Yes)
            {
                // If user chooses to reset
                RegoList.Clear();
                DisplayList();
                StripStatus.Text = "All data deleted";
                TextBoxInput.Clear();
                TextBoxInput.Select();
            }
            else
            {
                // If user chooses not to reset
                StripStatus.Text = "Data was not deleted";
            }
        }

        /*
         * TAG: Create tag method and associated TAG button to mark a rego plate. 
         * When a rego plate is selected from the ListBox and “tagged” an additional 
         * character value “z” will be prefixed to the rego plate. The List<> will 
         * be re-sorted and displayed.
         */
        private void ButtonTag_Click(object sender, EventArgs e)
        {
            string Rego = ListBoxOutput.SelectedItem.ToString();
            int RegoIndex = ListBoxOutput.SelectedIndex;

            if (!Rego.StartsWith("z"))
            {
                RegoList[RegoIndex] = "z" + Rego;
                DisplayList();
                StripStatus.Text = "Registration plate was tagged";
            }
            else
            {
                RegoList[RegoIndex] = Rego.Substring(1);
                DisplayList();
                StripStatus.Text = "Registration plate was untagged";
            }
            TextBoxInput.Clear();
            TextBoxInput.Select();

        }
        #endregion Reset/Tag

        #region Utilities

        /*
         * DISPLAY and SORT: All the rego plates should be displayed in the ListBox 
         * which is sorted alphabetically using the built-in List Sort method. The 
         * List<> must be sorted after every List<> process (add, edit, delete, etc). 
         * The rego plate information should be unique.
         */
        // TODO: Ensure no repeated entries
        public void DisplayList()
        {
            ListBoxOutput.Items.Clear();
            RegoList.Sort();
            foreach (var rego in RegoList)
            {
                ListBoxOutput.Items.Add(rego);
            }
        }

        /*
         * SINGLE DATA DISPLAY: Create a single click method to do the following: 
         * when a data item is selected from the ListBox on the left, the information 
         * is displayed in the TextBox on the right.
         */
        private void ListBoxOutput_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBoxInput.Text = ListBoxOutput.SelectedItem.ToString();
        }


        #endregion Utilities



    }
}
