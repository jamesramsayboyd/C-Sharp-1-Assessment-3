﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VehicleRegistrationForm
{

    /* James Boyd 30041547
     * C Sharp 1 Assessment 3
     * A program that tracks vehicle registrations in a large city car park
     * version 1.3 - All functionality implemented, full error trapping, 
     * full error messaging, tooltips implemented, code commented*/
    
    public partial class VehicleRegistration : Form
    {
        public VehicleRegistration()
        {
            InitializeComponent();
        }

        // Question 2:
        /* The prototype must use a List<> data structure of data 
         * type “string”.*/
        List<string> RegoList = new List<string>() { "1ADF-452", "1GFX-234", "1GTY-234", "1AFI-729", "1DBG-479", "1KIO-723", "1JPK-526", "1POR-319", "1XQP-749" };


        #region Open file/Save file
        
        // Question 3: 
        /* OPEN: The program reads default data into the List<> when 
         * it starts. When the OPEN button is clicked the user can 
         * select different data from a text file called “demo_nn.txt”*/
        private void ButtonOpen_MouseClick(object sender, MouseEventArgs e)
        {
            string fileName = "Rainbow.bin";
            OpenFileDialog OpenBinary = new OpenFileDialog();
            DialogResult sr = OpenBinary.ShowDialog();
            if (sr == DialogResult.OK)
            {
                fileName = OpenBinary.FileName;
            }
            try
            {
                RegoList.Clear();
                using (Stream stream = File.Open(fileName, FileMode.Open))
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    while (stream.Position < stream.Length)
                    {
                        RegoList.Add((string)binaryFormatter.Deserialize(stream));
                    }
                }
                DisplayList();
                StripStatus.Text = "Data loaded from file";
            }
            catch (IOException)
            {
                StripStatus.Text = "ERROR: Cannot open file";
            }
            catch (System.Runtime.Serialization.SerializationException)
            {
                StripStatus.Text = "ERROR: Please select a .txt or .bin file";
            }
        }

        /* CLOSE and SAVE: Create a SAVE button which will open a save 
         * dialog box and allow the user to save all the data back to 
         * a text file. When the program closes all data from the List<> 
         * will be written back to a single text file called 
         * “demo_nn.txt” file.*/
        private void ButtonSave_MouseClick(object sender, MouseEventArgs e)
        {
            string fileName = "Rainbow.bin";
            SaveFileDialog saveBinary = new SaveFileDialog();
            DialogResult sr = saveBinary.ShowDialog();
            if (sr == DialogResult.Cancel)
            {
                saveBinary.FileName = fileName;
            }
            if (sr == DialogResult.OK)
            {
                fileName = saveBinary.FileName;
            }
            try
            {
                using (Stream stream = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter binFormatter = new BinaryFormatter();
                    foreach (var item in RegoList)
                    {
                        binFormatter.Serialize(stream, item);
                    }
                }
                StripStatus.Text = "Data was saved to file";
            }
            catch (IOException)
            {
                StripStatus.Text = "ERROR: Cannot save file";
            }
        }

        #endregion Open file/Save file

        #region Enter/Leave/Edit
        // Question 4:
        /* ENTER Button: To add a rego plate to the List<> the user 
         * will type the data value (rego plate info) into the
         * TextBox and click the ENTER button. The data will be 
         * added to the List<> and the TextBox will be cleared, 
         * and the cursor will focus in the TextBox. If the TextBox 
         * is empty the program should raise an error message. */
        private void ButtonAdd_MouseClick(object sender, MouseEventArgs e)
        {
            // Checks to make sure user has entered a number in Text Box
            if (!string.IsNullOrEmpty(TextBoxInput.Text))
            {
                // Checks to make sure rego isn't too long
                if (TextBoxInput.Text.Length < 10)
                {
                    // Checks to make sure rego isn't already present in list
                    if (nonDuplicate(TextBoxInput.Text))
                    {
                        RegoList.Add(TextBoxInput.Text);
                        DisplayList();
                        TextBoxInput.Clear();
                        TextBoxInput.Select();
                        StripStatus.Text = "Registration plate added";
                    }
                    else
                        StripStatus.Text = "ERROR: Registration plate is already in list";
                }
                else
                    StripStatus.Text = "ERROR: Registration plates must not exceed 9 characters";
            }
            else
                StripStatus.Text = "ERROR: Enter a registration number in the Text Box";
        }

        // Question 5:
        /* LEAVE Button: There are two options 
         * to remove a rego plate item from the List<>. Method One: 
         * double click a data item from the ListBox and click the OK 
         * button in the popup dialog box. The data item will be removed 
         * from the List<>.*/
        private void ListBoxOutput_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(!string.IsNullOrEmpty(ListBoxOutput.SelectedItem as string))
                deleteRego(ListBoxOutput.SelectedItem.ToString());
        }

        /* Method Two: the user will enter the rego 
         * plate information into the TextBox and click the DELETE 
         * button. The data will be removed from the List<> and the 
         * TextBox will be cleared, and the cursor will focus in the TextBox.*/
        private void ButtonDelete_MouseClick(object sender, MouseEventArgs e)
        {
            // Checks to make sure list isn't empty
            if (RegoList.Count > 0)
            {
                // Checks that text is present in textbox (whether user has typed it or selected item)
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    // Checks to make sure user's entered text is present in list
                    if (RegoList.Contains(TextBoxInput.Text))
                        deleteRego(TextBoxInput.Text);
                    else
                        StripStatus.Text = "ERROR: Registration number not found";
                }
                else
                    StripStatus.Text = "ERROR: Select an item or type the registration plate";
            }
            else
                StripStatus.Text = "ERROR: Cannot delete, no data in list";
            
        }

        // Method to delete a list item using messagebox yes/no confirmation
        private void deleteRego(string a)
        {
            DialogResult delRecord = MessageBox.Show("Do you want to delete this registration number?",
                           "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (delRecord == DialogResult.Yes)
            {
                RegoList.Remove(a);
                DisplayList();
                TextBoxInput.Clear();
                TextBoxInput.Select();
                StripStatus.Text = "Registration number was deleted";
            }
            else
                StripStatus.Text = "Registration number was not deleted";
        }

        // Question 6:
        /* EDIT Button: To edit a rego plate click (select) a data item 
         * from the ListBox so that is appears in the TextBox. Alter the 
         * information and click the EDIT button. The updated information 
         * is written back to the List<> and the TextBox is cleared, and 
         * the cursor refocus in the TextBox. (you are not permitted to 
         * use an add/delete option)*/
        private void ButtonEdit_MouseClick(object sender, MouseEventArgs e)
        {
            // Checks to make sure there is data in the list
            if (RegoList.Count() > 0)
            {
                // Checks to see if user has selected an item in the Listbox
                if (ListBoxOutput.SelectedIndex != -1)
                {
                    // Checks to see if user has actually changed the rego
                    if (ListBoxOutput.SelectedItem.ToString() != TextBoxInput.Text && !string.IsNullOrEmpty(TextBoxInput.Text))
                    {
                        DialogResult delRecord = MessageBox.Show("Do you want to edit this record?",
                            "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                        if (delRecord == DialogResult.Yes)
                        {
                            RegoList[ListBoxOutput.SelectedIndex] = TextBoxInput.Text;
                            DisplayList();
                            StripStatus.Text = "Registration number was edited";
                            TextBoxInput.Clear();
                            TextBoxInput.Select();
                        }
                        else
                        {
                            TextBoxInput.Clear();
                            TextBoxInput.Select();
                            StripStatus.Text = "Registration number was not edited";
                        }
                    }
                    else
                        StripStatus.Text = "Please enter edited text";
                }
                else
                    StripStatus.Text = "ERROR: Cannot edit, no item selected";
            }
            else
                StripStatus.Text = "ERROR: Cannot edit, no data in list";
            
        }

        #endregion Enter/Leave/Edit

        #region Reset/Tag
        // Question 7:
        /* RESET: Add a RESET button to clear all the data items from the List<>. 
         * The ListBox and TextBox should also be cleared.*/
        private void ButtonReset_MouseClick(object sender, MouseEventArgs e)
        {
            if (RegoList.Count > 0)
            {
                DialogResult delRecord = MessageBox.Show("Do you want to delete all data?",
                    "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (delRecord == DialogResult.Yes)
                {
                    RegoList.Clear();
                    DisplayList();
                    TextBoxInput.Clear();
                    TextBoxInput.Select();
                    StripStatus.Text = "All data deleted";
                }
                else
                    StripStatus.Text = "Data was not deleted";
            }
            else
                StripStatus.Text = "ERROR: Cannot reset, no data in list";
        }

        // Question 13:
        /* TAG: Create tag method and associated TAG button to mark a rego plate. 
         * When a rego plate is selected from the ListBox and “tagged” an additional 
         * character value “z” will be prefixed to the rego plate. The List<> will 
         * be re-sorted and displayed.*/
        private void ButtonTag_MouseClick(object sender, MouseEventArgs e)
        {
            if (RegoList.Count > 0)
            {
                if (!string.IsNullOrEmpty(ListBoxOutput.SelectedItem as string))
                {
                    // Checks that registration plate hasn't already been tagged
                    if (!ListBoxOutput.SelectedItem.ToString().StartsWith("z"))
                    {
                        RegoList[ListBoxOutput.SelectedIndex] = "z" + ListBoxOutput.SelectedItem.ToString();
                        DisplayList();
                        StripStatus.Text = "Registration plate was tagged";
                    }
                    // If it has been tagged, untag it (remove the 'z')
                    else
                    {
                        RegoList[ListBoxOutput.SelectedIndex] = ListBoxOutput.SelectedItem.ToString().Substring(1);
                        DisplayList();
                        StripStatus.Text = "Registration plate was untagged";
                    }
                    TextBoxInput.Clear();
                    TextBoxInput.Select();
                }
            }
            else
            {
                // If the list is empty
                StripStatus.Text = "ERROR: Cannot tag, no data in list";
            }
        }
        #endregion Reset/Tag

        #region Utilities
        // Question 8:
        /* SINGLE DATA DISPLAY: Create a single click method to do the 
         * following: when a data item is selected from the ListBox on the 
         * left, the information is displayed in the TextBox on the right.*/
        private void ListBoxOutput_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ListBoxOutput.SelectedItem as string))
                TextBoxInput.Text = ListBoxOutput.SelectedItem.ToString();
        }

        // Question 9:
        /* DISPLAY and SORT: All the rego plates should be displayed 
         * in the ListBox which is sorted alphabetically using the 
         * built-in List Sort method. The List<> must be sorted after 
         * every List<> process (add, edit, delete, etc). The rego plate 
         * information should be unique.
         */
        public void DisplayList()
        {
            ListBoxOutput.Items.Clear();
            RegoList.Sort();
            foreach (var rego in RegoList)
                ListBoxOutput.Items.Add(rego);
        }

        // Textbox is cleared when double-clicking
        private void TextBoxInput_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            TextBoxInput.Clear();
        }

        // Prevents duplicate entries being added
        private bool nonDuplicate(string a)
        {
            if (RegoList.Exists(dup => dup.Equals(a)))
                return false;
            else
                return true;
        }

        // Displays default data on form load
        private void VehicleRegistration_Load(object sender, EventArgs e)
        {
            DisplayList();
        }

        #endregion Utilities

        #region Search

        // Question 10:        
        /* BINARY SEARCH: To find a specific rego plate the user will 
         * type the information into the TextBox and click the BINARY 
         * SEARCH button. If the rego plate is found, then a confirmation 
         * message should be displayed. If the rego plate is not found, 
         * then a message should be displayed, and the TextBox cleared, 
         * and the cursor refocused. The search code must use the 
         * built-in Binary search.*/
        private void ButtonBinary_MouseClick(object sender, MouseEventArgs e)
        {
            // Checks whether list is empty before searching
            if (RegoList.Count() > 0)
            {
                // Checks if user has entered a search query in the Text Box
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    int RegoIndex = RegoList.BinarySearch(TextBoxInput.Text);
                    if (RegoIndex >= 0)
                    {
                        StripStatus.Text = "Found via Binary Search";
                        ListBoxOutput.SelectedIndex = RegoIndex;
                    }
                    else
                        StripStatus.Text = "Not Found";
                    TextBoxInput.Clear();
                    TextBoxInput.Select();
                }
                else
                    StripStatus.Text = "ERROR: Enter a search target in the textbox";
            }
            else
                StripStatus.Text = "ERROR: Cannot search, no data in list";
        }

        // Question 11:
        /* LINEAR SEARCH: second search button that implements a linear 
         * search algorithm. To find a rego plate the user will type the 
         * information into the TextBox and click the LINEAR SEARCH button. 
         * If the rego plate is found, then a confirmation message should 
         * be displayed. If the rego plate is not found, then a message 
         * should be displayed, and the TextBox cleared, and the cursor 
         * refocused.*/
        private void ButtonLinear_MouseClick(object sender, MouseEventArgs e)
        {
            // Checks whether there is data in list
            if (RegoList.Count() > 0)
            {
                // Checks if user has entered a search target
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    string target = TextBoxInput.Text;
                    foreach (var rego in RegoList)
                    {
                        if (rego == target)
                        {
                            StripStatus.Text = "Found via Linear Search";
                            ListBoxOutput.SelectedItem = target;
                            break;
                        }
                        else
                            StripStatus.Text = "Not Found";
                        TextBoxInput.Clear();
                        TextBoxInput.Select();
                    }
                }
                else
                    StripStatus.Text = "ERROR: Enter a search target in the textbox";
            }
            else
                StripStatus.Text = "ERROR: Cannot search, no data in list";
        }

        #endregion Search

    }
}
